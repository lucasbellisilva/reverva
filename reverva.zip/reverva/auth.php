<?php
session_start();
$username = $_POST['username'];
$password = $_POST['password'];

$_SESSION['RERSERVAAPP'] = false;
$res = false;
if ($username != null && $password != null) {
    if ($username === "professor" && $password === "abcd1234") {
        $_SESSION['RERSERVAAPP'] = 'professor';
        $res = true;
    }elseif ($username === "escola" && $password === "abcd1234") {
        $_SESSION['RERSERVAAPP'] = 'escola';
        $res = true;
    }elseif ($username === "root" && $password === "abcd1234") {
        $_SESSION['RERSERVAAPP'] = 'root';
        $res = true;
    }else{
        unset($_SESSION['RERSERVAAPP'] );
    }
}else{
    unset($_SESSION['RERSERVAAPP'] );
}

header("Content-Type: application/json");
echo json_encode(['status' => $res]);
die();



